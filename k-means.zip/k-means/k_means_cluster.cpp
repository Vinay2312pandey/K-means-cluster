#include<stdio.h>
#include <cstdlib>
#include<bits/stdc++.h>
using namespace std;
int main()
{
	int  n, l, k;
	cin>>n>>k;
	float a[n][2], d;
	int i, j , m ,p;
	cout<<" give No of clusters "<<endl;
	float b[n][k];
	for(i=0; i<n; i++)
	{
		cin>>a[i][0]>>a[i][1];
	}
	//for(i=0; i<10; i++)
	//	cout<<a[i][0]<<"  "<<a[i][1]<<endl;
	int  x, y , z;
	int c[k];
	float mean[k][2], match[k][2];
	for(i=0; i<k; i++)
	{
		match[i][0] = 0;
		match[i][1] = 0;
	}
	for(i=0; i<k; i++)
	{
		m = rand()%n;
		c[i] = m;
		for(j=0; j<n; j++)
		{
			d = (a[m][0] - a[j][0])*(a[m][0] - a[j][0]) + (a[m][1] - a[j][1])*(a[m][1] - a[j][1]);
			d = sqrt(d);
			b[j][i] = d;
		//	cout<<"d = "<<d<<endl;
		}
	}
	
	float min=1000000;
	int f=1;
	int g=0;
	while(1 && f++<1000)
	{
		cout<<"--------------- ITERATION = "<<f<<" ----------------------------------"<<endl;
		for(i=0; i<n; i++)
		{
			min=1000000;
			for(x = 0; x <k ; x++)
			{
				if(min > b[i][x])
					min = b[i][x];
			}
			for(x = 0; x <k ; x++)
			{
				if(min != b[i][x])
				{
					b[i][x]=0;
				}
			}
		}
		int clus=1, tot=0;
		float mean1=0, mean2=0;
		for(j=0; j<k; j++)
		{
			int count =1;
			cout<<clus<<" = cluster ";
			if(f == 1)
				cout<<a[c[j]][0]<<"  "<<a[c[j]][1]<<" randomly selected value "<<endl;
			mean1=0; mean2=0;
			for(i=0; i<n; i++)
			{
				if(b[i][j] != 0)
				{
				//	cout<<count<<" = "<<a[i][0]<<"       "<<a[i][1]<<endl;
					mean1 = mean1 + a[i][0];
					mean2 = mean2 + a[i][1];
					count++;
					tot++;
				}
			}
			mean1 = mean1/count;
			mean2 = mean2/count;
			cout<<clus<<" = "<<"mean "<<mean1<<"   "<<mean2<<"      count = "<<count<<endl;
			clus++;
			mean[j][0] = mean1;
			mean[j][1] = mean2;
		}
		cout<<"total = "<<tot<<endl;
		
		for(i=0; i<k; i++)
		{
			for(j=0; j<n; j++)
			{
				d = (mean[i][0] - a[j][0])*(mean[i][0] - a[j][0]) + (mean[i][1] - a[j][1])*(mean[i][1] - a[j][1]);
				d = sqrt(d);
				b[j][i] = d;
			//	cout<<"d = "<<d<<endl;
			}
		}
		g=0;
		for(i=0; i<k; i++)
		{
			if(mean[i][0] != match[i][0]  || mean[i][1] != match[i][1])
			{
				g++;
				break;
			} 
		}
		if(g == 0)
		{
			cout<<" -------------- LAST ITERATION OVER-----------------------------"<<endl;
			break;
		}
		else
		{
			for(i=0; i<k; i++)
			{
				match[i][0] = mean[i][0];
				match[i][1] = mean[i][1];
			}
		}
		
	}	
}
